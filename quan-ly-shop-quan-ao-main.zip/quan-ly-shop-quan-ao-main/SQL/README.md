# CƠ SỞ DỮ LIỆU QUẢN LÝ SHOP QUẦN ÁO

## Nhóm 01

## Danh sách thành viên

- Trần Hữu Khải Quân (Trưởng nhóm)

- Nguyễn Thị Hà

- Nguyễn Trọng Hiếu

- Phạm Thị Hồng Nhung

## Tổng quan cấu trúc cơ sở dữ liệu

Cơ sở dữ liệu đáp ứng việc lưu trữ và quản lý thông tin của 1 cửa hàng quần áo nhỏ.
